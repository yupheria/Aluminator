<?php

class Gallery extends CI_Controller {

    function index() {
        $this->load->view('gallery');
    }

}
