<?php

class Donate extends CI_Controller {

    function index() {
        $this->load->view('donate');
    }

}
