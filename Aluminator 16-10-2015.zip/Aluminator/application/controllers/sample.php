<?php
class sample extends CI_Controller
{
	public function index()
	{
		echo "this is sample";		
	}
}


?>