<?php
$config['protocol']='smtp';  
$config['smtp_host']='ssl://smtp.googlemail.com';  
$config['smtp_port']= 465;  
$config['smtp_user']='aluminator2015@gmail.com';  
$config['smtp_pass']='@luminator';  
$config['mailtype']='html';
$config['newline']="\r\n";  
?>